/// themes/colors.jsx
export const primaryMain = "#F06D32";
export const secondaryMain = "#F6AF5EFF";
export const primaryLight = "#DFF98AFF";